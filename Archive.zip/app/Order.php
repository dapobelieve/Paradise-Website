<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'name',
        'email',
        'phone',
        'status',
        'meta',
        'amount',
        'hash'
    ];

    public function details()
    {
        return $this->hasMany(Detail::class);
    }
}
