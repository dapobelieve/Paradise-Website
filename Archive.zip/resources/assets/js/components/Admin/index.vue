<template>
    <div class="admin">
        <router-view></router-view>
    </div>
</template>
