export default {
    store: [],
    cart: [],
    userData: {}
}