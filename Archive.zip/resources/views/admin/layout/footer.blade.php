<div class="container">
    <div class="row">
        <div id="footer" class="col-xs-12">
            2012 - {{ date('Y')  }} &copy;  <a href="#">DapoBelieve</a>
        </div>
    </div>
</div>