<span id="store">
<admin-statistics></admin-statistics>
</span>