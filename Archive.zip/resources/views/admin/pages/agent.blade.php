<span id="store">
    <agent-dashboard-component></agent-dashboard-component>
</span>