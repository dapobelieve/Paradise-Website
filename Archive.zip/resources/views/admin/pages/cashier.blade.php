<span id="store">
    <cashier-dashboard-component></cashier-dashboard-component>
</span>