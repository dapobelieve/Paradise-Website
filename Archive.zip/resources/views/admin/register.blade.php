@extends('admin.layout.template')


@section('admin-content')

    <div id="content">
        <div id="content-header" class="mini">
            <h1>Dashboard</h1>
        </div>

        <div id="store">
            <admin-app></admin-app>
        </div>
        {{----}}
    </div>


@stop