<section class="pv-40 stats padding-bottom-clear dark-translucent-bg hovered background-img-7" style="background-position: 50% 50%;">
    <div class="clearfix">
        <div class="col-md-3 col-xs-6 text-center">
            <div class="feature-box object-non-visible" data-animation-effect="fadeIn" data-effect-delay="300">
                <span class="icon dark-bg large circle"><i class="fa fa-diamond"></i></span>
                <h3><strong>IT Services</strong></h3>
                <span class="counter" data-to="12" data-speed="5000">0</span>
            </div>
        </div>
        <div class="col-md-3 col-xs-6 text-center">
            <div class="feature-box object-non-visible" data-animation-effect="fadeIn" data-effect-delay="300">
                <span class="icon dark-bg large circle"><i class="fa fa-users"></i></span>
                <h3><strong>Customers</strong></h3>
                <span class="counter" data-to="12250" data-speed="5000">0</span>
            </div>
        </div>
        <div class="col-md-3 col-xs-6 text-center">
            <div class="feature-box object-non-visible" data-animation-effect="fadeIn" data-effect-delay="300">
                <span class="icon dark-bg large circle"><i class="fa fa-wifi"></i></span>
                <h3><strong>Internet Connections</strong></h3>
                <span class="counter" data-to="12235" data-speed="5000">0</span>
            </div>
        </div>
        <div class="col-md-3 col-xs-6 text-center">
            <div class="feature-box object-non-visible" data-animation-effect="fadeIn" data-effect-delay="300">
                <span class="icon dark-bg large circle"><i class="fa fa-cogs"></i></span>
                <h3><strong>Solar Installs</strong></h3>
                <span class="counter" data-to="1500" data-speed="5000">0</span>
            </div>
        </div>
    </div>
</section>