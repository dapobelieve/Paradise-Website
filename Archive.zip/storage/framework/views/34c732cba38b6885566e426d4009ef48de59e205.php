<?php $__env->startSection('admin-content'); ?>

    <div id="content">
        <div id="content-header" class="mini">
            <h1>Dashboard</h1>
        </div>
        <div id="breadcrumb">
            <a href="#" title="Go to Home" class="tip-bottom"><i class="fa fa-home"></i> Home</a>
            <a href="#" class="current">Users</a>
        </div>
        <div class="container-fluid">
            <br />
            <div class="row">
                <div class="col-xs-12">
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-info">
                            <strong>*</strong>
                            <?php echo e(Session::get('message')); ?>

                            <a href="#" data-dismiss="alert" class="close">×</a>
                        </div>
                    <?php endif; ?>
                    <div class="widget-box">
                        <div class="widget-content">
                            <div class="table-responsive widget-content nopadding">
                                <table class="data-table table table-bordered table-striped table-hover with-check">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Ip address</th>
                                        <th>Role(s)</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index + 1); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><?php echo e($user->ip); ?></td>
                                            <td>
                                            <?php $__currentLoopData = $user->roles()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($role->name); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td><a href="<?php echo e(route('edit-user', ['user' => $user->id])); ?>">Edit Role</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>