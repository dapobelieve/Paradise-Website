<?php $__env->startSection('admin-content'); ?>

<div id="content">
    <div id="content-header" class="mini">
        <h1>Dashboard</h1>
    </div>
    <?php if(Auth::user()->hasRole(['agent'])): ?>
        <?php echo $__env->make('admin.pages.agent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->hasRole(['cashier'])): ?>
        <?php echo $__env->make('admin.pages.cashier', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('admin.pages.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>