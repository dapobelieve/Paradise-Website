<?php $__env->startSection('site.title', ' | Paradise Digital World'); ?>

<?php $__env->startSection('site.content'); ?>

    <section class="main-container">
        <div class="container">
            <div class="row">

                <!-- main start -->
                <!-- ================ -->
                <div class="main col-md-8">
                    <h1 class="page-title"><?php echo e($property->title); ?></h1>
                    <article class="blogpost full">
                        <header>
                            <div class="post-info">
                                <span class="submitted"><i class="icon-user-1"></i> by <a href="#">Paradise Admin</a></span>
                            </div>
                        </header>
                        <div class="blogpost-content">
                            <div id="carousel-blog-post" class="carousel slide mb-20" data-ride="carousel">
                                <!-- Indicators -->
                                <ol class="carousel-indicators">
                                    <?php $__currentLoopData = $property->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li data-target="#carousel-blog-post" data-slide-to="<?php echo e($loop->index); ?>" class="<?php if($loop->index == 0): ?> active <?php endif; ?>"></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>

                                <!-- Wrapper for slides -->
                                <div class="carousel-inner" role="listbox">
                                    <?php $__currentLoopData = $property->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item <?php if($loop->index + 1 == 1): ?> active <?php endif; ?>">

                                            <img style="object-fit: cover; height: 100%; width: 100%" src="<?php echo e(json_decode($image->url, true)['secure_url']); ?>" alt="">

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <h4>Price:  &#8358;<?php echo e(number_format($property->price)); ?></h4>
                            <p><?php echo e($property->details); ?></p>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>