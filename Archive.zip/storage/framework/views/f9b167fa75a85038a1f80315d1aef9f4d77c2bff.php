<div id="sidebar">
    

        <ul>
            <li><a href="<?php echo e(url('dashboard#/stats')); ?>">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
            </li>
            <?php if(Auth::user()->hasRole(['admin'])): ?>
                



                <li class="submenu">
                    <a href="#"><i class="fa fa-home"></i> <span>Properties</span> <i class="arrow fa fa-chevron-right"></i></a>
                    <ul>
                        <li><a href="<?php echo e(route('all-properties')); ?>">All Properties</a></li>
                        <li><a href="<?php echo e(route('property.add')); ?>">Add Property</a></li>
                    </ul>
                </li>
                <li class="submenu">
                    <a href="#">
                        <i class="fa fa-users"></i> <span>Workers</span><i class="arrow fa fa-chevron-right"></i>
                    </a>
                    <ul>

                        <li><a href="<?php echo e(route('add.user')); ?>">All Users</a></li>

                    </ul>
                </li>
                <li class="submenu">
                    <a href="#"><i class="fa fa-shopping-cart"></i> <span>Products</span> <i class="arrow fa fa-chevron-right"></i></a>
                    <ul>
                        <li><a href="<?php echo e(route('store.index')); ?>">All Product</a></li>

                    </ul>
                </li>
                <li><a href="#">
                    <i class="fa fa-home"></i> <span>Orders</span></a>
                </li>



            <?php elseif(Auth::user()->hasRole(['admin', 'agent'])): ?>
                <li>
                    <a href="<?php echo e(route('agent.transact')); ?>">
                        <i class="fa fa-laptop"></i> <span>Transact</span>
                    </a>
                </li>
            <?php elseif(Auth::user()->hasRole(['admin', 'cashier'])): ?>





            <?php endif; ?>
            <li>
                <a href="<?php echo e(route('site.home')); ?>" target="_blank">
                    <i class="fa fa-globe"></i> <span>Website</span>
                </a>
            </li>
        </ul>

</div>