<?php

return [
    'defaults' => [
        'name' => 'Paradise Digital World',
        'session' => '2018/2019',
        'regPrice' => 3000,
        'supportPrice' => 2500
    ],
    'keys' => [
        'paystack_sk' => 'sk_test_f7bfe6376e280ac4c9527543d96109f99fd1ee7b'
    ]
];