<template>
    <div class="solar">
        <div class="container">
            <div class="row">
                <!-- main start -->
                <!-- ================ -->
                <div class="main object-non-visible" data-animation-effect="fadeInUpSmall" data-effect-delay="100">
                    <div class="form-block center-block p-30 light-gray-bg border-clear">
                        <h2 style="color: #000" class="center-block">Solar Training Registration</h2>
                        <form class="form-horizontal" role="form">
                            <div class="form-group has-feedback">
                                <label for="inputName" class="col-sm-3 control-label">Full Name <span class="text-danger small">*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" v-model="form.name" class="form-control" placeholder="Full Name"  >
                                </div>
                            </div>
                            <div class="form-group has-feedback">
                                <label for="inputEmail" class="col-sm-3 control-label">Email <span class="text-danger small">*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" v-model="form.email" class="form-control" placeholder="Email Address"  >
                                </div>
                            </div>
                            <div class="form-group has-feedback">
                                <label for="inputLastName" class="col-sm-3 control-label">Phone Number <span class="text-danger small">*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" v-model="form.phone" class="form-control" placeholder="Phone Number"  >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label"> Status <span class="text-danger small">*</span></label>
                                <div class="col-sm-8">
                                    <select name="status" v-model="form.status" class="form-control">
                                        <option selected>---Select---</option>
                                        <option value="student">Student</option>
                                        <option value="non-student">Not Student</option>
                                    </select>
                                    <span class="has-error">

                                    </span>
                                </div>
                            </div>
                            <div class="form-group has-feedback">
                                <label for="inputEmail" class="col-sm-3 control-label">Contact Address <span class="text-danger small">*</span></label>
                                <div class="col-sm-8">
                                    <textarea v-model="form.address" name="address" rows="5" class="form-control" >
                                        {{  }}
                                    </textarea>
                                    <i class="fa fa-map-marker form-control-feedback"></i>
                                    <span class="has-error">

                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-8">
                                <div class="checkbox">
                                    <label>
                                        <input v-model="form.agree" type="checkbox" > Accept our <a href="#">privacy policy</a> and <a href="#">customer agreement</a>
                                    </label>
                                </div>
                            </div>
                        </div>
                            <div class="form-group">
                                <div class="col-sm-offset-3 col-sm-8">
                                    <button @click.prevent="processForm" class="btn btn-group btn-default btn-animated">Register <i class="fa fa-check"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- main end -->
            </div>
        </div>
    </div>
    
</template>

<script>
    export default {
        data () {
            return {
                form : {
                    name: "",
                    email: "",
                    phone: "",
                    status: "",
                    address: "",
                    agree: false

                }
            }
        },
        methods: {
          processForm () {
              if (!this.form.agree) {
                  alert('All fields required');
                  return;
              }


          }
        },
        mounted() {
            // alert('Solar Registration')
        }
    }
</script>

<style scoped>

</style>