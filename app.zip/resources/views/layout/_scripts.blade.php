<script src="{{ asset('js/app.js') }}"></script>
<script type="text/javascript" src="/assets/plugins/jquery.min.js"></script>
        <script type="text/javascript" src="/assets/bootstrap/js/bootstrap.min.js"></script>

        <!-- Modernizr javascript -->
        <script type="text/javascript" src="/assets/plugins/modernizr.js"></script>

        <!-- jQuery Revolution Slider  -->
        <script type="text/javascript" src="/assets/plugins/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="/assets/plugins/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>     

        <!-- Isotope javascript -->
        <script type="text/javascript" src="/assets/plugins/isotope/isotope.pkgd.min.js"></script>
        
        <!-- Magnific Popup javascript -->
        <script type="text/javascript" src="/assets/plugins/magnific-popup/jquery.magnific-popup.min.js"></script>
        
        <!-- Appear javascript -->
        <script type="text/javascript" src="/assets/plugins/waypoints/jquery.waypoints.min.js"></script>

        <!-- Count To javascript -->
        <script type="text/javascript" src="/assets/plugins/jquery.countTo.js"></script>
        
        <!-- Parallax javascript -->
        <script src="/assets/plugins/jquery.parallax-1.1.3.js"></script>
        <script type="text/javascript" src="/assets/plugins/owl-carousel/owl.carousel.js"></script>

        <!-- SmoothScroll javascript -->
        <script type="text/javascript" src="/assets/plugins/jquery.browser.js"></script>
        <script type="text/javascript" src="/assets/plugins/SmoothScroll.js"></script>
        <!-- Initialization of Plugins -->
        <script type="text/javascript" src="/assets/js/template.js"></script>

        <!-- Custom Scripts -->
        <script type="text/javascript" src="/assets/js/custom.js"></script>
        <!-- Color Switcher (Remove these lines) -->
        <!-- Color Switcher End -->