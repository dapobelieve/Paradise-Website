@extends('template')

@section('site.title', 'Solar Training Registration | Paradise Digital World')

@section('site.content')
    <div class="main-container dark-translucent-bg" style="background-image:url('/assets/paradise/solar-img.jpg');">
        <div id="store">
            <solar></solar>
        </div>
    </div>
@stop