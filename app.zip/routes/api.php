<?php

Route::group(['middleware' => 'api'], function () {
    Route::get('store', 'Store\StoreController@index');
    Route::get('get-states', 'Api\DataController@getStates');

    // parttime endpoint
    Route::post('save_pt_record', 'Api\PartTimeController@save');

    Route::get('verify/{ref}', 'Api\VerifyController@verifyTransaction');

    // store cart details
    Route::post('record-transaction', 'Store\StoreController@record');

    // update refcode status
    Route::get('ref-update/{transaction}', 'Api\VerifyController@updateRefCode');

    Route::get('verify-payment/{transaction}/{ref}', 'Api\VerifyPayment@verify');

    /**
     * Registration Parts
     */
    Route::get('get-students', 'Api\RegController@getAllReg');
    Route::get('student-detail/{student}', 'Api\RegController@getStudent');


});