<?php $__env->startSection('admin-content'); ?>

<div id="content">
    <div id="content-header" class="mini">
        <h1>Dashboard</h1>
    </div>
    <div id="breadcrumb">
        <a href="#" title="Go to Home" class="tip-bottom"><i class="fa fa-home"></i> Home</a>
        <a href="#" class="current">Dashboard</a>
    </div>
    <div class="container-fluid">
        
        <br />

        <div class="row">
            <div class="col-xs-12">
                
                <div class="widget-box">
                    <div class="widget-content">
                        <div class="row">
                            <div class="col-md-12">
                                <form action="<?php echo e(route('service.add')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                                    <div class="form-group">
                                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Service Name: </label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" required name="title" class="form-control input-sm" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Service Image: </label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="file" name="pimage" class="form-control input-sm" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Service Details: </label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <textarea name="details" required class="form-control" name="" id="" cols="30" rows="8"></textarea>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 col-md-3 col-lg-2 control-label"> </label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <button class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>

                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </div>  
                        </div>                          
                    </div>
                </div>                  
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>