<!DOCTYPE html>
<html lang="en">


<?php echo $__env->make('admin.layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>   

    <body data-color="grey" class="flat">
        <div id="wrapper">
            <div id="header">
                <h1><a href="#">Unicorn Admin</a></h1>   
                <a id="menu-trigger" href="#"><i class="fa fa-bars"></i></a>    
            </div>
        
            
           
            <?php echo $__env->make('admin.layout.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            

            <?php echo $__env->yieldContent('admin-content'); ?>
            

            <?php echo $__env->make('admin.layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

            <?php echo $__env->make('admin.layout.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>


</html>
