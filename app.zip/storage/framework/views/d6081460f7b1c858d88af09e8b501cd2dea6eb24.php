<!DOCTYPE html>
<html lang="en">


<?php echo $__env->make('admin.layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>   

    <body data-color="grey" class="flat">
        <div id="wrapper">
            <div id="header">
                <h1><a href="index-2.html">Unicorn Admin</a></h1>   
                <a id="menu-trigger" href="#"><i class="fa fa-bars"></i></a>    
            </div>
        
            <?php echo $__env->make('admin.layout.topnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           
            

            <?php echo $__env->yieldContent('admin-content'); ?>
            

            <?php echo $__env->make('admin.layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

            <script src="/authmin/js/excanvas.min.js"></script>
            <script src="/authmin/js/jquery.min.js"></script>
            <script src="/authmin/js/jquery-ui.custom.js"></script>
            <script src="/authmin/js/bootstrap.min.js"></script>
            <script src="/authmin/js/jquery.flot.min.js"></script>
            <script src="/authmin/js/jquery.flot.resize.min.js"></script>
            <script src="/authmin/js/jquery.sparkline.min.js"></script>
            <script src="/authmin/js/fullcalendar.min.js"></script>
            
            <script src="/authmin/js/jquery.nicescroll.min.js"></script>
            <script src="/authmin/js/unicorn.js"></script>
            <script src="/authmin/js/unicorn.dashboard.js"></script>
    </body>


</html>
