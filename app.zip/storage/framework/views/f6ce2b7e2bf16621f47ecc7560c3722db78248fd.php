<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="/authmin/js/excanvas.min.js"></script>
<script src="/authmin/js/jquery.min.js"></script>
<script src="/authmin/js/jquery-ui.custom.js"></script>
<script src="/authmin/js/bootstrap.min.js"></script>
<script src="/authmin/js/jquery.nicescroll.min.js"></script>
<script src="/authmin/js/unicorn.js"></script>
