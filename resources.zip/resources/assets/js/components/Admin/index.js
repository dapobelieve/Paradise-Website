import Vue from 'vue';

export const Index = Vue.component('index', require('./index.vue'));
export const StudentList = Vue.component('studentList', require('./Students.vue'));
export const StudentDetails = Vue.component('studentDetails', require('./details.vue'));