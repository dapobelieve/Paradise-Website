<head>
    <title>Dashboard</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="/authmin/css/bootstrap.min.css" />
    <link rel="stylesheet" href="/authmin/css/font-awesome.css" />
    <link rel="stylesheet" href="/authmin/css/jquery.jscrollpane.css" />
    <link rel="stylesheet" href="/authmin/css/unicorn.css" />
</head> 