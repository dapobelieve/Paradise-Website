<?php $__env->startSection('site.title', $service->title.' | Botium-Intl'); ?>

<?php $__env->startSection('site.content'); ?>
    <section class="main-container">

                <div class="container">
                    <div class="row">

                        <!-- main start -->
                        <!-- ================ -->
                        <div class="main col-md-8">

                            <!-- page-title start -->
                            <!-- ================ -->
                            <h1 class="page-title"><?php echo e($service->title); ?></h1>
                            <!-- page-title end -->

                            <!-- blogpost start -->
                            <!-- ================ -->
                            <article class="blogpost full">
                                
                                <div class="blogpost-content">
                                    <div id="carousel-blog-post" class="carousel slide mb-20" data-ride="carousel">
                                         <img src="/storage/original/<?php echo e($service->getImage()); ?>" alt="">
                                        <!-- Wrapper for slides -->
                                        <div class="carousel-inner" role="listbox">
                                            <div class="item">
                                                <div class="overlay-container">
                                                    <img src="/storage/original/<?php echo e($service->getImage()); ?>" alt="">
                                                    <a class="overlay-link popup-img" href="/storage/original/<?php echo e($service->getImage()); ?>""><i class="fa fa-search-plus"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <p><?php echo e($service->body); ?></p>
                                </div>
                                
                            </article>
                            <!-- blogpost end -->
                        </div>
                        <!-- main end -->

                        <!-- sidebar start -->
                        <!-- ================ -->
                        <aside class="col-md-4 col-lg-3 col-lg-offset-1">
                            
                        </aside>
                        <!-- sidebar end -->
                    </div>
                </div>
            </section>

    <?php echo $__env->make('layout._cta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>