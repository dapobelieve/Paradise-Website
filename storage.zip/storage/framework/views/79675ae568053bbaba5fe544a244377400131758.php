<?php $__env->startSection('site.title', 'Funaab Registrations | Paradise Digital World'); ?>

<?php $__env->startSection('site.content'); ?>
    
    <script>
        <?php if(Auth::check()): ?>
        localStorage.setItem('paraUser', '<?php echo Auth::user(); ?>')
        <?php else: ?>
        localStorage.removeItem('paraUser');
        <?php endif; ?>
    </script>
    <div id="store" class="store">

        <main-app></main-app>

    </div>
    <?php echo $__env->make('layout._cta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>