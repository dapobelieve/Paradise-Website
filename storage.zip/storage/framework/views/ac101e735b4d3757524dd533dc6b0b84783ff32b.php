<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
<style>
    body {
        font-family: 'Open Sans', sans-serif;
        /*background-color: #f6f6f6;*/
    }
    a {
        text-decoration: none;
    }
</style>
</head>
<body>

<div style="font-family: Open Sans; margin: 10px">
    <div style=" padding-top: 5px; padding-bottom: 20px; padding-right: 50px; padding-left: 50px; margin: 0px;">
        <h4><?php echo e($request->subject); ?></h4>
        <p>
            <?php echo e($request->message); ?>

        </p>
    </div>
    
</div>

</body>
</html>