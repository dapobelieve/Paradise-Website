<?php $__env->startSection('admin-content'); ?>

    <div id="content">
        <div id="content-header" class="mini">
            <h1>Dashboard</h1>
        </div>

        <div id="store">
            <admin-app></admin-app>
        </div>
        
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>