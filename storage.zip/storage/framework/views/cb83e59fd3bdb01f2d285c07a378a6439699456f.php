<div class="modal fade" id="paradiseAlert" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <h4 class="modal-title text-center" id="myModalLabel">FUNAAB POST JAMB APPLICATION FORMS IS OUT!!!</h4>
                    </div>
                    <div class="modal-body">
                        <p>We will help you to register accordingly and send the print out back to you on both Email and WhatsApp. Just download the form, fill it and scan back to us. There is no need to come in person. Distance is not a barrier. We at Paradise Digital World are reputable for the job.</p>
                        <p>Also attach the following documents/items:</p>
                        <ul>
                            <li>UTME Number</li>
                            <li>O Level Results</li>
                            <li>Passport Photograph</li>
                        </ul>
                        <p>Below is the break down of the registration process and fee</p>
                        <img class="img-responsive" src="https://res.cloudinary.com/invitro/image/upload/v1563907560/paradisePostUtme.jpg">
                        <br>
                        <p>
                            Account Info: PARADISE DIGITAL WORLD, GTB, 0050933270
                        </p>
                        <p>
                            Once the payment is confirmed, the registration will be done and sent to you. 
                            <bold></bold>
                        </p>
                        <form method="get" action="https://res.cloudinary.com/invitro/image/upload/v1563906228/paradise/POST_UTME_APPLICATION_FORM.pdf">
                           <button class="btn btn-default" type="submit">Download Post UTME Form</button>
                        </form>

                        <p>FUNAAB POST JAMB PAST QUESTION AVAILABLE <a href="<?php echo e(route('site.post-jamb')); ?>">HERE</a></p>
                    </div>
                </div>
            </div>
        </div>