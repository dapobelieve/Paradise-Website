<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layout._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>        
</head>
    <body class="no-trans front-page transparent-header ">

        <div class="scrollToTop circle"><i class="icon-up-open-big"></i></div>
        
        <!-- page wrapper start -->
        <!-- ================ -->
        <div class="page-wrapper">
        
            <!-- header-container start -->
            <div class="header-container">
                <!-- ================ -->
                <?php echo $__env->make('layout._header-dark', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <header class="header  fixed   clearfix">
                    
                    <div class="container">
                        <div class="row">
                            <div class="col-md-3">
                                <!-- header-left start -->
                                <!-- ================ -->
                                <div class="header-left clearfix">

                                    <!-- logo -->
                                    <div id="logo" class="logo">
                                        <a href="<?php echo e(route('site.home')); ?>">
                                            <img width="85px"  id="logo_img" src="/assets/images/dlogo.png" alt="Paradise Logo"></a>
                                    </div>

                                    <!-- name-and-slogan -->
                                    <div class="site-slogan">
                                        Paradise Digital World
                                    </div>
                                    
                                </div>
                                <!-- header-left end -->
                            </div>
                            <div class="col-md-9">
                                <div class="header-right">
                                    <?php echo $__env->make('layout._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>                    
                            </div>
                        </div>
                    </div>
                    
                </header>
                <!-- header end -->
            </div>
            <!-- header-container end -->
            <?php echo $__env->yieldContent('site.content'); ?>

            <?php echo $__env->make('layout._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <?php echo $__env->make('layout._modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('layout._scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
<?php if(Session::has('errorMessage')): ?>
    alert('<?php echo e(Session::get('errorMessage')); ?>');
<?php endif; ?>
   
</script>
<?php echo $__env->yieldContent('site.scripts'); ?>
    </body>
</html>
