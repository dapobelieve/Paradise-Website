<div id="sidebar">
      
    <ul>
        <li><a href="#">
            <i class="fa fa-home"></i> <span>Dashboard</span></a>
        </li>
        <li><a href="<?php echo e(url('registrations#/list')); ?>">
                <i class="fa fa-users"></i> <span>Registrations</span></a>
        </li>

        <li class="submenu">
            <a href="#"><i class="fa fa-flask"></i> <span>Products</span> <i class="arrow fa fa-chevron-right"></i></a>
            <ul>
                <li><a href="<?php echo e(route('store.index')); ?>">All Product</a></li>
                <li><a href="<?php echo e(route('store.add')); ?>">Add Product</a></li>
            </ul>
        </li>

        <li><a href="#">
            <i class="fa fa-home"></i> <span>Orders</span></a>
        </li>

        <li><a href="<?php echo e(route('solar.index')); ?>">
            <i class="fa fa-home"></i> <span>Solar Training</span></a>
        </li>

        
    </ul>
</div>