<?php $__env->startSection('site.title', 'Solar Training Registration | Paradise Digital World'); ?>

<?php $__env->startSection('site.content'); ?>
    <div class="main-container dark-translucent-bg" style="background-image:url('/assets/paradise/solar-img.jpg');">
        <div id="store">
            <solar></solar>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>